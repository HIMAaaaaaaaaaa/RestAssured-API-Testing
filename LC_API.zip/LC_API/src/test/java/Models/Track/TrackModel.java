package Models.Track;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrackModel {
    public String Id;
    public String Title;
    public String Description;
    public int MembersCount;
    public int CoursesCount;
    public List<Map<String, Object>> Courses;
    public String OwnerName;
    public boolean TrackOwner;
    public String IsPublished;
    public int TrackProgress;
    public String TrackSetting;
    public boolean IsOrganizationCertificateEnabled;

    public TrackModel() {
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public int getMembersCount() {
        return MembersCount;
    }

    public void setMembersCount(int membersCount) {
        MembersCount = membersCount;
    }

    public int getCoursesCount() {
        return CoursesCount;
    }

    public void setCoursesCount(int coursesCount) {
        CoursesCount = coursesCount;
    }

    public List<Map<String, Object>> getCourses() {
        return Courses;
    }

    public void setCourses(List<Map<String, Object>> courses) {
        Courses = courses;
    }

    public String getOwnerName() {
        return OwnerName;
    }

    public void setOwnerName(String ownerName) {
        OwnerName = ownerName;
    }

    public boolean isTrackOwner() {
        return TrackOwner;
    }

    public void setTrackOwner(boolean trackOwner) {
        TrackOwner = trackOwner;
    }

    public String getIsPublished() {
        return IsPublished;
    }

    public void setIsPublished(String isPublished) {
        IsPublished = isPublished;
    }

    public int getTrackProgress() {
        return TrackProgress;
    }

    public void setTrackProgress(int trackProgress) {
        TrackProgress = trackProgress;
    }

    public String getTrackSetting() {
        return TrackSetting;
    }

    public void setTrackSetting(String trackSetting) {
        TrackSetting = trackSetting;
    }

    public boolean isOrganizationCertificateEnabled() {
        return IsOrganizationCertificateEnabled;
    }

    public void setOrganizationCertificateEnabled(boolean organizationCertificateEnabled) {
        IsOrganizationCertificateEnabled = organizationCertificateEnabled;
    }
}
