package APIsTest.Track;

import APIs.Authentication.AuthAPI;
import APIs.Track.AddTrackAPI;
import APIs.Track.DeleteTrackAPI;
import DataSteps.Track.AddTrackData;
import APIs.Body.Track.AddTrackBody;
import Environment.EnvironmentData;
import Models.Auth.AuthAPIModel;
import Models.Track.TrackModel;
import io.restassured.response.Response;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import static org.testng.Assert.assertEquals;


public class AddTrackTest {

    AuthAPIModel authAPIModel;
    TrackModel trackModel;

    @BeforeClass
    public void setUp() {
        // Print Test Suite Name
        System.out.println("Test Add Track API");
        // Read Users Data From Json File
       // usersData = JsonFileReader.readDataFile();
        // Get Admin Token
        authAPIModel= AuthAPI.authRequest(EnvironmentData.LCAdmin, EnvironmentData.Password);

    }

    @Test(description = "Add Track With Title And Description")
    public void addTrackWithTitleAndDescription() {
        // Generate Add Track Body
        AddTrackBody addTrackBody = AddTrackData.generateAddTrackDataBody(AddTrackData.BodyType.FULL_BODY);
        // Call Add Track API and Get Response
        Response response = AddTrackAPI.addTrack(authAPIModel.getAccess_token(), addTrackBody);
        System.out.println(response.asString());
        // trackModel = new TrackModel(response.jsonPath());
        // Make Object form Track Model
        trackModel = response.body().as(TrackModel.class);
        // Assert That Status Code is 200
        response.then().assertThat().statusCode(200);
        // Assert That Title And Description of The Track as it created
        assertEquals(trackModel.getTitle(), addTrackBody.getTitle(), "Title Not match");
        assertEquals(trackModel.getDescription(), addTrackBody.getDescription(), "Description Not match");
    }


    @AfterMethod(description = "Delete Track")
    public void deleteTrack() {
        if (trackModel != null)
            DeleteTrackAPI.deleteTrack(authAPIModel.getAccess_token(), trackModel.getId());
    }
}
