package APIs.CertificateBuilder;

import Environment.EnvironmentData;
import Environment.Routes;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import java.util.List;

import static io.restassured.RestAssured.given;

public class CertificateBuilderAPI {

    public static Response certificateBuilder(String token) {
        return given()
                .baseUri(EnvironmentData.BASEURLTesting)
                .auth().oauth2(token)
                .when()
                .get(Routes.CertificateBuilder);
    }

    public static List<Integer> getCertificationIDs(String token) {
        // Convert The response to JsonPath
        JsonPath response = certificateBuilder(token).jsonPath();
        // Return List Of Certification IDs
        return response.getList("Id");
    }
}
