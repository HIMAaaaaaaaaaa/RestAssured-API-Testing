package APIs.Authentication;

import Environment.EnvironmentData;
import Environment.Routes;
import Models.Auth.AuthAPIModel;
import Models.Track.TrackModel;
import RestActions.RestActions;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import java.util.HashMap;

public class AuthAPI {
    public static AuthAPIModel authRequest(String UserName, String Password) {
        HashMap<String, String> query = new HashMap<>();
        query.put("grant_type", "password");
        query.put("client_id", "Ibtikar");
        query.put("client_secret", "e868a216-276b-4899-aaa4-8cbe06a9f496");
        query.put ("username", UserName);
        query.put("password", Password);
  Response response= new  RestActions(EnvironmentData.BASEURLTesting).sendPostRequestWithFormDataBody(query , Routes.AUTHAPI, "Content-Type","application/x-www-form-urlencoded");
        return response.getBody().as(AuthAPIModel.class);
    }

}
