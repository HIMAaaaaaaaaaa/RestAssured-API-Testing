package APIs.Course;

import Environment.EnvironmentData;
import Environment.Routes;
import io.restassured.response.Response;

import java.util.List;

import static io.restassured.RestAssured.given;


public class GetCoursesAPI {

    public enum CoursesStates {
        PUBLISHED_COURSES,
        DRAFT_COURSES,
        ARCHIVE_COURSES,
    }

    public static Response getPublishedCourses(String token) {
        String body = "{\n" +
                "    \"pageNumber\": 1,\n" +
                "    \"schoolIds\": [],\n" +
                "    \"orderBy\": \"0\",\n" +
                "    \"courseKeyWord\": \"\",\n" +
                "    \"instructorId\": null,\n" +
                "    \"courseStatus\": 1,\n" +
                "    \"getPendingRequestsCount\": true,\n" +
                "    \"pinStatus\": null,\n" +
                "    \"CoursesCount\": null,\n" +
                "    \"GetArchivedCourses\": false,\n" +
                "    \"OrganizationTermId\": null,\n" +
                "    \"CustomFieldsSearchCrieteria\": []\n" +
                "}";
        return given()
                .baseUri(EnvironmentData.BASEURLTesting)
                .contentType("application/json")
                .auth().oauth2(token)
                .body(body)
                .when()
                .post(Routes.GetCourses);
    }

    public static Response getDraftCourses(String token) {
        String body = "{\n" +
                "    \"pageNumber\": 1,\n" +
                "    \"schoolIds\": [],\n" +
                "    \"orderBy\": \"0\",\n" +
                "    \"courseKeyWord\": \"\",\n" +
                "    \"instructorId\": null,\n" +
                "    \"courseStatus\": 0,\n" +
                "    \"getPendingRequestsCount\": true,\n" +
                "    \"pinStatus\": null,\n" +
                "    \"CoursesCount\": null,\n" +
                "    \"GetArchivedCourses\": false,\n" +
                "    \"OrganizationTermId\": null,\n" +
                "    \"CustomFieldsSearchCrieteria\": []\n" +
                "}";
        return given()
                .baseUri(EnvironmentData.BASEURLTesting)
                .contentType("application/json")
                .auth().oauth2(token)
                .body(body)
                .when()
                .post(Routes.GetCourses);
    }

    public static Response getArchiveCourses(String token) {
        String body = "{\n" +
                "    \"pageNumber\": 1,\n" +
                "    \"schoolIds\": [],\n" +
                "    \"orderBy\": \"0\",\n" +
                "    \"courseKeyWord\": \"\",\n" +
                "    \"instructorId\": null,\n" +
                "    \"courseStatus\": null,\n" +
                "    \"getPendingRequestsCount\": true,\n" +
                "    \"pinStatus\": null,\n" +
                "    \"CoursesCount\": null,\n" +
                "    \"GetArchivedCourses\": true,\n" +
                "    \"OrganizationTermId\": null,\n" +
                "    \"CustomFieldsSearchCrieteria\": []\n" +
                "}";
        return given()
                .baseUri(EnvironmentData.BASEURLTesting)
                .contentType("application/json")
                .auth().oauth2(token)
                .body(body)
                .when()
                .post(Routes.GetCourses);
    }

    public static List<Integer> getCoursesID(String token, CoursesStates coursesStates) {
        Response response =
                coursesStates == CoursesStates.PUBLISHED_COURSES ? getPublishedCourses(token)
                        : coursesStates == CoursesStates.DRAFT_COURSES ? getDraftCourses(token)
                        : getArchiveCourses(token);

        // Extract Courses IDs
        return response.jsonPath().getList("UnPinnedCourses.Id");
    }
}
