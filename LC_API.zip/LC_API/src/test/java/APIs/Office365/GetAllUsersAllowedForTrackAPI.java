package APIs.Office365;

import Environment.EnvironmentData;
import Environment.Routes;
import io.restassured.response.Response;

import java.util.List;

import static io.restassured.RestAssured.given;

public class GetAllUsersAllowedForTrackAPI {

    private static Response getAllUsersAllowedForTrack(String token, String trackID) {
        return given()
                .baseUri(EnvironmentData.BASEURLTesting)
                .queryParam("id", trackID)
                .contentType("application/json")
                .auth().oauth2(token)
                .when()
                .get(Routes.GetAllUsersAllowedForTrack);
    }


    public static List<Integer> getUsersID(String token, String trackID) {
        // Call All Users Allowed For Track API
        Response response = getAllUsersAllowedForTrack(token, trackID);
        // Get List of User IDs
        return response.jsonPath().getList("Learners");
    }
}
