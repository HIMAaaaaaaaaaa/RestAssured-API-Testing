package APIs.Office365;

import Environment.EnvironmentData;
import Environment.Routes;
import io.restassured.response.Response;

import java.util.List;

import static io.restassured.RestAssured.given;

public class GetAdminTenantSchoolsBasicInfoAPI {
    String token;

    private static Response getAllUsersAllowedForTrack(String token) {
        return given()
                .baseUri(EnvironmentData.BASEURLTesting)
                .contentType("application/json")
                .auth().oauth2(token)
                .when()
                .get(Routes.GetAdminTenantSchoolsBasicInfo);
    }

    public static List<String> getSchoolID(String token) {
        Response response = getAllUsersAllowedForTrack(token);
        // Get List of SchoolIDs in the Organization
        return response.jsonPath().getList("SchoolId");
    }

}
