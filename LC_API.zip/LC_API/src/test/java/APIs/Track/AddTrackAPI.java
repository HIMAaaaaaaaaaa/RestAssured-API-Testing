package APIs.Track;

import APIs.Body.Track.AddTrackBody;
import Environment.EnvironmentData;
import Environment.Routes;
import RestActions.RestActions;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;


public class AddTrackAPI {

    private static final RequestSpecification requestSpecification =
            new RequestSpecBuilder().setBaseUri(EnvironmentData.BASEURLTesting)
                    .build();

    public static Response addTrack(String token, AddTrackBody body) {
        return new RestActions(EnvironmentData.BASEURLTesting,token).sendPostRequest(body,Routes.AddTrack);
    }

    public static Response addTrackWithoutBody(String token) {

        return given().spec(requestSpecification).
                contentType("application/json").
                auth().oauth2(token).
                body("").
                when().post(Routes.AddTrack);
    }

    public static Response addTrackWithoutToken(AddTrackBody body) {

        return given().spec(requestSpecification).
                contentType("application/json").
                body(body).
                when().post(Routes.AddTrack);
    }

    public static Response addTrackWithoutContentType(String token, AddTrackBody body) {

        return given().spec(requestSpecification).
                auth().oauth2(token).
                body(body).
                when().post(Routes.AddTrack);
    }

    public static Response addTrackWithWrongMethod(String token, AddTrackBody body) {

        return given().spec(requestSpecification).
                contentType("application/json").
                auth().oauth2(token).
                body(body).
                when().get(Routes.AddTrack);
    }
}
