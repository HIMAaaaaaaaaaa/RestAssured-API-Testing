package APIs.Track;


import Environment.EnvironmentData;
import Environment.Routes;
import RestActions.RestActions;

import java.util.HashMap;




public class DeleteTrackAPI {

    public static void deleteTrack(String token, String trackID) {
        HashMap<String,String> params = new HashMap<>();
        params.put("trackId", trackID);
        new RestActions (EnvironmentData.BASEURLTesting, token).sendDeleteRequestWithQueryParams(params, Routes.DeleteTrack);

    }


}
