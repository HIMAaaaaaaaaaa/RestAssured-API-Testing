package DataSteps.Track;

import APIs.Body.Track.AddTrackBody;
import com.github.javafaker.Faker;

public class AddTrackData {

    public enum BodyType {
        FULL_BODY,
        TITLE_ONLY,
        DESCRIPTION_ONLY
    }

    public static AddTrackBody generateAddTrackDataBody(BodyType bodyType) {
        Faker faker = new Faker();
        String title = bodyType == BodyType.DESCRIPTION_ONLY ? "" : faker.name().title();
        String description = bodyType == BodyType.TITLE_ONLY ? "" : faker.lorem().paragraph(1);
        return new AddTrackBody(title, description);
    }
}
