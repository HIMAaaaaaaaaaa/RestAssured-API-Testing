package RestActions;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import java.util.HashMap;

import static io.restassured.RestAssured.given;

public class RestActions {

    private final   String baseURL;
     private String token;

    public RestActions(String baseURL) {
        this.baseURL = baseURL;

    }

    public RestActions(String baseURL, String token) {
        this.baseURL = baseURL;
        this.token = token;
    }

    public Response sendPostRequest(Object body, String route) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).
                    contentType("application/json").
                    auth().oauth2(token).
                    body(body).
                    when().post(route);
        } else {
            response = given().baseUri(baseURL).
                    contentType("application/json").
                    body(body).
                    when().post(route);
        }
        return response;
    }

    public Response sendPostRequest(Object body, String route, String headerKey, Object headerValue) {


        Response response;
        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token).
                    body(body).
                    when().post(route);
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    body(body).
                    when().post(route);
        }
        return response;
    }
    public Response sendPostRequest( String route, String headerKey, Object headerValue) {


        Response response;
        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token).
                    when().post(route);
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    when().post(route);
        }
        return response;
    }
    public Response sendPostRequest( String route) {
        Response response;
        if (token != null) {
            response = given().baseUri(baseURL).
                    auth().oauth2(token).
                    when().post(route);
        } else {
            response = given().baseUri(baseURL).
                    when().post(route);
        }
        return response;
    }

    public Response sendPostRequestWithFormDataBody(HashMap<String, String> formData, String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .formParams(formData)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .formParams(formData)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }

    public Response sendPostRequestWithFormDataBody(HashMap<String, String> formData, String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .formParams(formData)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .formParams(formData)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }



    public Response sendPostRequestWithFormDataBody(HashMap<String, String> formData, Object body,String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .formParams(formData)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .formParams(formData)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }

    public Response sendPostRequestWithFormDataBody(HashMap<String, String> formData, Object body,String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .formParams(formData)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .formParams(formData)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }




    public Response sendPostRequestWithQueryParams(HashMap<String, String> queryParam, String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .queryParams(queryParam)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .queryParams(queryParam)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendPostRequestWithQueryParams(HashMap<String, String> queryParam, String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .queryParams(queryParam)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .queryParams(queryParam)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendPostRequestWithQueryParams(HashMap<String, String> queryParam, Object body, String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .queryParams(queryParam)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .queryParams(queryParam)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendPostRequestWithQueryParams(HashMap<String, String> queryParam,Object body,  String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .queryParams(queryParam)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .queryParams(queryParam)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendPostRequestWithPathParams(HashMap<String, String> pathParams, Object body, String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .pathParams(pathParams)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .pathParams(pathParams)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendPostRequestWithPathParams(HashMap<String, String> pathParam,Object body,  String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .pathParams(pathParam)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .queryParams(pathParam)
                    .body(body)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }

    public Response sendPostRequestWithPathParams(HashMap<String, String> pathParams, String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .pathParams(pathParams)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .pathParams(pathParams)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendPostRequestWithPathParams(HashMap<String, String> pathParams, String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .pathParams(pathParams)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .pathParams(pathParams)
                    .post(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendDeleteRequestWithFormDataBody(HashMap<String, String> formData, String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .formParams(formData)
                    .delete(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .formParams(formData)
                    .delete(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }

    public Response sendDeleteRequestWithFormDataBody(HashMap<String, String> formData, String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .formParams(formData)
                    .delete(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .formParams(formData)
                    .delete(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }

    public void sendDeleteRequestWithQueryParams(HashMap<String, String> queryParam, String route) {



        if (token!=null)
        {
             given().baseUri(baseURL).
                    auth().oauth2(token)
                    .queryParams(queryParam)
                    .delete(route);//Make post action//


        }
        else {
           given().baseUri(baseURL)
                    .queryParams(queryParam)
                    .delete(route);//Make post action//


        }


    }
    public void sendDeleteRequestWithQueryParams(HashMap<String, String> queryParam, String route, String headerKey, Object headerValue) {


        if (token != null) {
            given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .queryParams(queryParam)
                    .delete(route);//Make post action//

        } else {
             given().baseUri(baseURL).header(headerKey, headerValue)
                    .queryParams(queryParam)
                    .delete(route);//Make post action//

        }



    }
    public void sendDeleteRequestWithPathParams(HashMap<String, String> pathParams, String route) {



        if (token!=null)
        {
             given().baseUri(baseURL).
                    auth().oauth2(token)
                    .pathParams(pathParams)
                    .delete(route);//Make post action//

        }
        else {
             given().baseUri(baseURL)
                    .pathParams(pathParams)
                    .delete(route);//Make post action//

        }



    }
    public void sendDeleteRequestWithPathParams(HashMap<String, String> pathParams, String route, String headerKey, Object headerValue) {


        if (token != null) {
             given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .pathParams(pathParams)
                    .delete(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
             given().baseUri(baseURL).header(headerKey, headerValue)
                    .pathParams(pathParams)
                    .delete(route);//Make post action//

        }



    }

    public Response sendGetRequestWithFormDataBody(HashMap<String, String> formData, String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .formParams(formData)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .formParams(formData)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }

    public Response sendGetRequestWithFormDataBody(HashMap<String, String> formData, String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .formParams(formData)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .formParams(formData)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }

    public Response sendGetRequestWithQueryParams(HashMap<String, String> queryParam, String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .queryParams(queryParam)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .queryParams(queryParam)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendGetRequestWithQueryParams(HashMap<String, String> queryParam, String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .queryParams(queryParam)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .queryParams(queryParam)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendGetRequestWithPathParams(HashMap<String, String> pathParams, String route) {


        Response response;
        if (token!=null)
        {
            response = given().baseUri(baseURL).
                    auth().oauth2(token)
                    .pathParams(pathParams)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        }
        else {
            response = given().baseUri(baseURL)
                    .pathParams(pathParams)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }
    public Response sendGetRequestWithPathParams(HashMap<String, String> pathParams, String route, String headerKey, Object headerValue) {
        Response response;

        if (token != null) {
            response = given().baseUri(baseURL).header(headerKey, headerValue).
                    auth().oauth2(token)
                    .pathParams(pathParams)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        } else {
            response = given().baseUri(baseURL).header(headerKey, headerValue)
                    .pathParams(pathParams)
                    .get(route)//Make post action//
                    .then()
                    .extract().response();
        }


        return response;
    }

    public  int getStatusCode (Response response)
    {
        return response.getStatusCode();
    }


}
