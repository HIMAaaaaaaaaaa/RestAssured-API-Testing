package DataReader;
import java.io.*;
import java.util.HashMap;
import java.util.Properties;
public class PropertyFilesReader {

    public  HashMap<String,String> loadData(String filePath){
        Properties properties = new Properties();
        HashMap<String,String> fileProperties= new HashMap<>();
        try (InputStream inputStream =  getClass().getClassLoader().getResourceAsStream(filePath)){
            // Load the properties file
          if (inputStream!=null)
          {
              properties.load(inputStream);
              properties.forEach((key, value) -> fileProperties.put((String) key, (String) value));

          }


        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileProperties;
    }
    }





