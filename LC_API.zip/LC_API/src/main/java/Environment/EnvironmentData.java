package Environment;

import DataReader.PropertyFilesReader;

import java.util.Map;

public class EnvironmentData {

    public static String BASEURLTesting;
    public static String BASEURLStaging;
    public static String LCAdmin;
    public static String LCAdmin2;
    public static String LCTrainingCoordinator;
    public static String LCInstructor;
    public static String LCTrainee;
    public static String Password;
    public static String Password2;


    static {
        addPropertiesValue();
    }



    private static void addPropertiesValue(){
      var loadEnvironmentDataProperties =   new PropertyFilesReader().loadData("Environment/EnvironmentData.properties");
        for(Map.Entry<String,String> entry : loadEnvironmentDataProperties.entrySet())
        {
            String key = entry.getKey();
            String value = entry.getValue();

            switch (key){
                case "BASEURLTesting":BASEURLTesting=value;
                    break;
                case "BASEURLStaging":BASEURLStaging=value;
                    break;
                case "LCAdmin" :LCAdmin=value;
                    break;
                case "LCAdmin2":LCAdmin2=value;
                    break;
                case "LCTrainingCoordinator":LCTrainingCoordinator=value;
                    break;
                case "LCTrainee":LCTrainee=value;
                    break;
                case "LCInstructor":LCInstructor=value;
                    break;
                case "Password":Password=value;
                    break;
                case "Password2":Password2=value;
                    break;
                default:
                    System.out.println("Failed to load property");

            }
        }


    }


}



