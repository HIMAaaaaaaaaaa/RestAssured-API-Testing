package Environment;

import DataReader.PropertyFilesReader;

import java.util.Map;

public class Routes {
    public static String GetAllUsersAllowedForTrack;
    public static String GetAdminTenantSchoolsBasicInfo;
    public static String AUTHAPI;
    public static String CertificateBuilder;
    public static String GetCourses;
    public static String AddTrack;
    public static String DeleteTrack;

    static {
        addPropertiesValue();

    }




    private static void addPropertiesValue(){
        var loadRoutesProperties =   new PropertyFilesReader().loadData("Environment/Routes.properties");
        for(Map.Entry<String,String> entry : loadRoutesProperties.entrySet())
        {
            String key = entry.getKey();
            String value = entry.getValue();

            switch (key){
                case "GetAllUsersAllowedForTrack":GetAllUsersAllowedForTrack=value;
                    break;
                case "GetAdminTenantSchoolsBasicInfo":GetAdminTenantSchoolsBasicInfo=value;
                    break;
                case "AUTHAPI" :AUTHAPI=value;
                    break;
                case "CertificateBuilder":CertificateBuilder=value;
                    break;
                case "GetCourses":GetCourses=value;
                    break;
                case "AddTrack":AddTrack=value;
                    break;
                case "DeleteTrack":DeleteTrack=value;
                    break;
                default:
                    System.out.println("Failed to load property");

            }
        }


    }
}
